//
//  ViewController.swift
//  SokobanLite
//
//  Created by admin on 24/05/15.
//  Copyright (c) 2015 free. All rights reserved.
//

import UIKit

var round = 0
var moves = 0

class ViewController: UIViewController {
    
    let room : Room = Room(width: 15, height: 10)
    
    @IBOutlet weak var mainView   : UILabel!
    @IBOutlet weak var winLabel   : UILabel!
    @IBOutlet weak var roundLabel : UILabel!
    @IBOutlet weak var movesLabel : UILabel!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()

        startNewRound()
        updateLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // ***** Actions *****
    
    @IBAction func up() {
        room.moveHumanByDirection(.Up)
        updateLabels()
    }
    
    @IBAction func down() {
        room.moveHumanByDirection(.Down)
        updateLabels()
    }
    
    @IBAction func left() {
        room.moveHumanByDirection(.Left)
        updateLabels()
    }
    
    @IBAction func right() {
        room.moveHumanByDirection(.Right)
        updateLabels()
    }
    
    @IBAction func restart() {
        startNewRound()
        updateLabels()
    }
    
    // ***** Main *****
    
    func updateLabels() {
        winLabel.hidden = !room.win()
        mainView.text = room.draw()
        roundLabel.text = String(round)
        movesLabel.text = String(moves)
    }
    
    func startNewRound() {
        round++
        room.reset()
        room.setHuman( Human(x: 7, y: 4) )
        room.addBox( Box(x: 2, y: 4) )
        room.addBox( Box(x: 8, y: 6) )
        room.addBox( Box(x: 11, y: 4) )
        room.addDest( Destination(x: 8, y: 3) )
        room.addDest( Destination(x: 1, y: 7) )
        room.addDest( Destination(x: 12, y: 2) )
    }
    
    // ***** Classes, Structs *****
    
    enum Direction {
        case Left
        case Right
        case Up
        case Down
    }
    
    struct Human {
        var x : Int
        var y : Int
        
        mutating func moveWithDir(dir: Direction) {
            switch dir {
            case .Left:  x--
            case .Right: x++
            case .Down:  y--
            case .Up:    y++
            default: break
            }
            moves++
        }
    }
    
    struct Box {
        var x : Int
        var y : Int
        
        mutating func moveWithDir(dir: Direction) {
            switch dir {
            case .Left:  x--
            case .Right: x++
            case .Down:  y--
            case .Up:    y++
            default: break
            }
        }
    }
    
    struct Destination {
        var x : Int
        var y : Int
    }
    
    class Room {
        var width : Int
        var height : Int
        
        var human : Human = Human(x: 1, y: 1)
        var boxes : [Box]
        var dests : [Destination]
        
        init(width: Int, height: Int) {
            self.height = height <= 0 ? 1 : height
            self.width = width <= 0 ? 1 : width
            self.boxes = [Box]()
            self.dests = [Destination]()
        }
        
        func reset() {
            self.human = Human(x: 1, y: 1)
            self.boxes = [Box]()
            self.dests = [Destination]()
        }
        
        func setHuman(newHuman: Human) {
            self.human = newHuman
        }
        
        func addBox(newBox: Box) {
            boxes.append(newBox)
        }
        
        func addDest(newDest: Destination) {
            dests.append(newDest)
        }
        
        func draw() -> String {
            return wall() + board() + wall()
        }
        func wall() -> String {
            var line = ""
            for i in 0...self.width {
                line += "\u{25FE}"
            }
            line += "\u{25FE}\n"
            return line
        }
        func board() -> String {
            
            var board = ""
            var flag : Bool
            
            for i in reverse(1...self.height) {
                board += "\u{25FE}"
            
                for j in 1...self.width {
                    
                    flag = true
                    
                    if human.x == j && human.y == i {   // human
                        board += "\u{1F6B6}"
                        flag = false
                    }
                    
                    for box in boxes {
                        if flag && box.x == j && box.y == i {
                            board += "\u{1F4B0}"
                            flag = false
                            break
                        }
                    }
                    
                    for dest in dests {
                        if flag && dest.x == j && dest.y == i {
                            board += "\u{1F539}"
                            flag = false
                            break
                        }
                    }
                    
                    if flag {
                        board += "\u{25FD}"
                    }
                }
                board += "\u{25FE}\n"
            }
            return board
        }
        
        func win() -> Bool {
            
            var countWin = 0
            
            for box in boxes {
                for dest in dests {
                    countWin += box.x == dest.x && box.y == dest.y ? 1 : 0
                }
            }
            return countWin == boxes.count
        }

    
        func moveHumanByDirection(dir: Direction) {
            
            var nextBox : Int? = nil
            var secondBox : Int? = nil

            switch dir {
                
            case .Left:
                for var i = 0; i < boxes.count; i++ {
                    if boxes[i].x == human.x - 1 && boxes[i].y == human.y {
                        nextBox = i
                    }
                    if boxes[i].x == human.x - 2 && boxes[i].y == human.y {
                        secondBox = i
                    }
                }
                if nextBox != nil && secondBox == nil {
                    if boxes[nextBox!].x > 1 {
                        boxes[nextBox!].moveWithDir(.Left)
                        human.moveWithDir(.Left)
                    }
                } else if human.x > 1 && nextBox == nil {
                    human.moveWithDir(.Left)
                }
            
            case .Right:
                
                for var i = 0; i < boxes.count; i++ {
                    if boxes[i].x == human.x + 1 && boxes[i].y == human.y {
                        nextBox = i
                    }
                    if boxes[i].x == human.x + 2 && boxes[i].y == human.y {
                        secondBox = i
                    }
                }
                if nextBox != nil && secondBox == nil {
                    if boxes[nextBox!].x < width {
                        boxes[nextBox!].moveWithDir(.Right)
                        human.moveWithDir(.Right)
                    }
                } else if human.x + 1 <= width && nextBox == nil {
                    human.moveWithDir(.Right)
                }
                
            case .Down:
                
                for var i = 0; i < boxes.count; i++ {
                    if boxes[i].y == human.y - 1 && boxes[i].x == human.x {
                        nextBox = i
                    }
                    if boxes[i].y == human.y - 2 && boxes[i].x == human.x {
                        secondBox = i
                    }
                }
                if nextBox != nil && secondBox == nil {
                    if boxes[nextBox!].y > 1 {
                        boxes[nextBox!].moveWithDir(.Down)
                        human.moveWithDir(.Down)
                    }
                } else if human.y > 1 && nextBox == nil {
                    human.moveWithDir(.Down)
                }
                
            case .Up:
                
                for var i = 0; i < boxes.count; i++ {
                    if boxes[i].y == human.y + 1 && boxes[i].x == human.x {
                        nextBox = i
                    }
                    if boxes[i].y == human.y + 2 && boxes[i].x == human.x {
                        secondBox = i
                    }
                }
                if nextBox != nil && secondBox == nil {
                    if boxes[nextBox!].y < height {
                        boxes[nextBox!].moveWithDir(.Up)
                        human.moveWithDir(.Up)
                    }
                } else if human.y + 1 <= height && nextBox == nil {
                    human.moveWithDir(.Up)
                }

            default:
                break
            }
        }
    }
}

